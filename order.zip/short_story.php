<?php
$category = 'Short Story';
require __DIR__ . '/includes/book_category.php';
$likedIds = getLikedIds($pdo);
?>
