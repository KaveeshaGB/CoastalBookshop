<?php
$category = 'Fiction';
require __DIR__ .'/includes/book_category.php';
$likedIds = getLikedIds($pdo);
?>